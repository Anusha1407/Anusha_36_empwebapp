package com.capgemini.empwebapp.dao;

import java.util.List;

import com.capgemini.empwebapp.dto.EmployeeBean;

public interface EmployeeDao {
	public EmployeeBean getEmpByid(int Id);

	public boolean addEmp(EmployeeBean bean);

	public boolean updateEmp(EmployeeBean bean);

	public boolean deleteEmp(int Id);

	public List<EmployeeBean> getAllEmpDetails();

	public EmployeeBean login(int empId, String password);
}
