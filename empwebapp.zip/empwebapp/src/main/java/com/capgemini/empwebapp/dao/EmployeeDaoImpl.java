package com.capgemini.empwebapp.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.empwebapp.dto.EmployeeBean;

public class EmployeeDaoImpl implements EmployeeDao {
	Connection con = null;
	PreparedStatement prepstmt = null;
	ResultSet rs = null;

	String dbUrl = "jdbc:mysql://localhost:3306/emp";
	String user = "Anu";
	String pass = "9SreeRama9@1";

	public EmployeeBean getEmpByid(int empId) {
		EmployeeBean empInfoBean = null;

		try {
			con = DriverManager.getConnection(dbUrl, user, pass);
			prepstmt = con.prepareStatement("select * from empinfo where empId=?");
			prepstmt.setInt(1, empId);
			rs = prepstmt.executeQuery();
			if (rs.next()) {
				empInfoBean = new EmployeeBean();
				empInfoBean.setEmpId(rs.getInt("empId"));
				empInfoBean.setAge(rs.getInt("age"));
				empInfoBean.setEmpName(rs.getString("name"));
				empInfoBean.setDesignation(rs.getString("designation"));
				empInfoBean.setPassword(rs.getString("password"));
				empInfoBean.setSalary(rs.getDouble("salary"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (prepstmt != null) {
				try {
					prepstmt.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return empInfoBean;
	}

	public boolean addEmp(EmployeeBean bean) {

		String query1 = "insert into empinfo values(?,?,?,?,?,?)";

		try {
			con = DriverManager.getConnection(dbUrl, user, pass);

			prepstmt = con.prepareStatement(query1);

			prepstmt.setInt(1, bean.getEmpId());
			prepstmt.setString(2, bean.getEmpName());
			prepstmt.setInt(3, bean.getAge());
			prepstmt.setDouble(4, bean.getSalary());
			prepstmt.setString(5, bean.getDesignation());
			prepstmt.setString(6, bean.getPassword());

			int result = prepstmt.executeUpdate();

			if (result != 0) {
				System.out.println("values are inserted succefully");
			}
			con.close();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		return false;
	}

	public boolean updateEmp(EmployeeBean bean) {
		EmployeeBean empbean = null;
		boolean isUpdated = false;

		try {
			con = DriverManager.getConnection(dbUrl, user, pass);
			prepstmt = con.prepareStatement("update empinfo set empname=? where empid=? ");
			prepstmt.setString(1, bean.getEmpName());
			prepstmt.setInt(2, bean.getEmpId());

			int result = prepstmt.executeUpdate();
			if (result > 0) {
				System.out.println("values are updated succefully");
				isUpdated = true;
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		return isUpdated;
	}

	public boolean deleteEmp(int Id) {
		EmployeeBean empbean = null;
		boolean isDeleted = false;

		try {
			con = DriverManager.getConnection(dbUrl, user, pass);
			prepstmt = con.prepareStatement("delete from  empinfo  where EmpId=?");

			prepstmt.setInt(1, empbean.getEmpId());

			int result = prepstmt.executeUpdate();
			if (result > 0) {
				System.out.println("values deleted succefully");
				isDeleted = true;
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		return isDeleted;
	}

	public List<EmployeeBean> getAllEmpDetails() {
		List<EmployeeBean> listInfo = new ArrayList<EmployeeBean>();

		ResultSet rs = null;

		try {
			con = DriverManager.getConnection(dbUrl, user, pass);
			prepstmt = con.prepareStatement("select * from empinfo");
			rs = prepstmt.executeQuery();

			while (rs.next()) {
				EmployeeBean bean2 = new EmployeeBean();

				bean2.setEmpName(rs.getString("name"));
				bean2.setAge(rs.getInt("Age"));
				bean2.setPassword(rs.getString("password"));
				bean2.setDesignation(rs.getString("designation"));
				bean2.setSalary(rs.getDouble("salary"));
				bean2.setEmpId(rs.getInt("empId"));

				listInfo.add(bean2);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return listInfo;
	}

	public EmployeeBean login(int empId, String pass) {
		EmployeeBean empInfoBean = getEmpByid(empId);
		if (!(empInfoBean != null && empInfoBean.getPassword().equals(pass))) {
			empInfoBean = null;
		}
		return null;
	}
}
