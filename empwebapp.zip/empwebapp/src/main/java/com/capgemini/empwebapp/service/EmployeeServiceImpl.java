package com.capgemini.empwebapp.service;

import java.util.List;

import com.capgemini.empwebapp.dao.EmployeeDao;
import com.capgemini.empwebapp.dao.EmployeeDaoImpl;
import com.capgemini.empwebapp.dto.EmployeeBean;


public class EmployeeServiceImpl implements EmployeeService{
	EmployeeDao empdao=new EmployeeDaoImpl();

	public EmployeeBean getEmpByid(int Id) {
		// TODO Auto-generated method stub
		return empdao.getEmpByid(Id);
	}

	public boolean addEmp(EmployeeBean bean) {
		// TODO Auto-generated method stub
		return empdao.addEmp(bean);
	}

	public boolean updateEmp(EmployeeBean bean) {
		// TODO Auto-generated method stub
		return empdao.updateEmp(bean);
	}

	public boolean deleteEmp(int Id) {
		// TODO Auto-generated method stub
		return empdao.deleteEmp(Id);
	}

	public List<EmployeeBean> getAllEmpDetails() {
		// TODO Auto-generated method stub
		return null;
	}

	public EmployeeBean login(int empId, String password) {
		// TODO Auto-generated method stub
		return empdao.login(empId, password);
	}

}
