package com.capgemini.empwebapp.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.empwebapp.dto.EmployeeBean;
import com.capgemini.empwebapp.service.EmployeeService;
import com.capgemini.empwebapp.service.EmployeeServiceImpl;

@WebServlet("./addemp")
public class AddEmployee extends HttpServlet{
	EmployeeService empService = new EmployeeServiceImpl();
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String empId1 = req.getParameter("empId");
		int empId = Integer.parseInt(empId1);
		String empName  = req.getParameter("empName");
		String ageVal = req.getParameter("age");
		int age  = Integer.parseInt(ageVal);
		String  salary1 = req.getParameter("salary");
        double salary = Double.parseDouble(salary1);
        String designation  = req.getParameter("designation");
        String password = req.getParameter("password");
        
        EmployeeBean empBean = new EmployeeBean();
        empBean.setEmpId(empId);
        empBean.setEmpName(empName);
        empBean.setAge(age);
        empBean.setSalary(salary);
        empBean.setDesignation(designation);
        empBean.setPassword(password);
		resp.setContentType("test/html");
		
		boolean added = empService.addEmp(empBean);
		
		PrintWriter out = resp.getWriter();
		
		out.println("<html>");
		out.println("<body>");
		if(added) {
			out.print("<h2 style='color: yellow'>Employee Added Succesfully</h2>");
			
		}else {
			out.print("<h2 style='color: red'>Unable to add succefully!!</h2>");

		}
		out.println("EmployeeId" +empId);
		out.println("<br>EmployyeName= "+empName);
		out.println("<br>Employee age : " +age);
		out.println("<br>Employee salary : " +salary);
		out.println("<br>designation : " +designation);
		out.println("<br>Employee password : " +password);
		out.println("</body>");
		out.println("</html>");
		RequestDispatcher dispatcher =req.getRequestDispatcher("./homepage.html");
		dispatcher.include(req, resp);
		
		}
	

}
